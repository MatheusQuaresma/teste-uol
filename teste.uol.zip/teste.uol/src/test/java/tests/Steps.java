package tests;

import elementos.Elementos;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Metodos;

public class Steps {

	Metodos metodos = new Metodos();
	Elementos el = new Elementos();

	@Given("que eu esteja no site {string}")
	public void que_eu_esteja_no_site(String url) throws InterruptedException {
		metodos.abrirNavegador(url);

	}

	@When("buscar o produto Faded Short Sleeve")
	public void buscar_o_produto_faded_short_sleeve() throws InterruptedException {
		metodos.preencher(el.digitarProduto, "Faded Short Sleeve");
		metodos.clicar(el.buscarProduto);
		metodos.pausa(3000);
		metodos.clicar(el.selecionarProduto);
	}

	@When("adicionar no carrinho")
	public void adicionar_no_carrinho() throws InterruptedException {
		metodos.pausa(3000);
		metodos.clicar(el.addCarrinho);
	}

	@Then("validar o produto dentro do carrinho")
	public void validar_o_produto_dentro_do_carrinho() throws InterruptedException {
		metodos.pausa(3000);
		metodos.validarTexto(el.validarProduto, "Product successfully added to your shopping cart");
		metodos.fecharNavegador();
	}

}
