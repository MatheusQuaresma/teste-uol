package elementos;

import org.openqa.selenium.By;

public class Elementos {
	
	//buscar produto
	public By digitarProduto = By.id("search_query_top");
	
	public By buscarProduto = By.name("submit_search");
	
	//Adicionar produto ao carrinho
	
	public By selecionarProduto = By.xpath("//*[@id=\"center_column\"]/ul/li");
	
	public By addCarrinho = By.id("add_to_cart");
	
	public By validarProduto = By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[1]/h2");

}
